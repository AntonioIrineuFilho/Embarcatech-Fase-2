#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include <math.h>
#include "ssd1306.h"

#define DATA_PIN   16  // Qh do 74HC166
#define CLOCK_PIN  17  // CLK
#define LOAD_PIN   28  // /LOAD

#define I2C_PORT i2c1
#define I2C_SDA 15
#define I2C_SCL 14

#define BTN_B_PIN 6

ssd1306_t tela;

int estadoBtnB = 1;

int valor = 0;


void exibirTela(){

    // converte de int para string  
    char string[16];

    sprintf(string, "%d", valor); 

    ssd1306_clear(&tela);

    ssd1306_draw_string(&tela, 10, 10, 2, string);
    
    sleep_ms(500);

    ssd1306_show(&tela);

}

void func(){

    valor = 0;

    // carrega os dados
    gpio_put(LOAD_PIN, 0);
    sleep_us(5); 
    gpio_put(LOAD_PIN, 1);

    for(int i=0; i<8; i++){

        int bit = gpio_get(DATA_PIN); 
        if(bit == 1){
            valor += pow(2, i); 
        }

        // Gera o próximo bit com pulso de clock
        gpio_put(CLOCK_PIN, 1);
        sleep_us(1);  // pequeno atraso
        gpio_put(CLOCK_PIN, 0);
        sleep_us(1);
    }

    exibirTela();
}


void setup(){   

    stdio_init_all();

    // Configurações dos pinos
    gpio_init(DATA_PIN);
    gpio_set_dir(DATA_PIN, GPIO_IN);

    gpio_init(CLOCK_PIN);
    gpio_set_dir(CLOCK_PIN, GPIO_OUT);

    gpio_init(LOAD_PIN);
    gpio_set_dir(LOAD_PIN, GPIO_OUT);

    gpio_put(LOAD_PIN, 1);
    gpio_put(CLOCK_PIN, 0);

    // botao b
    gpio_init(BTN_B_PIN);
    gpio_set_dir(BTN_B_PIN, GPIO_IN);
    gpio_pull_up(BTN_B_PIN);
    

    //tela
    i2c_init(I2C_PORT, 400*1000);
    
    gpio_set_function(I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA);
    gpio_pull_up(I2C_SCL);
   
    ssd1306_init(&tela, 128, 64, 0x3C, I2C_PORT);
    
}

int main()
{
    setup();

    while (true) {
        estadoBtnB = gpio_get(BTN_B_PIN);
        if(estadoBtnB == 0){
            func();
        }
        
    }
}
